<?php

$dbms = 'mysql';
$dbserv = 'localhost';
$dbuser = 'smartiechick';
$dbpass = 'goedzo000';
$dbname = 'smartiechick';
$dbport = false;

$subdir = '/roadsterspot/';

define("MAPS_HOST", "maps.google.com");
define("MAPS_KEY", "");

define('DEBUG', false);
define('DEBUG_EXTRA', false);